package com.report;

import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.constant.TestConstant;


public class ExcelUtils {
	

	private static XSSFSheet ExcelWorkSheet;

	private static XSSFWorkbook ExcelWorkBook;
	
	private static XSSFCell Cell;

	private static XSSFRow Row;
	
	int a;
	
	
	public static void readExcelFilePath() throws Exception{
		
		try {
			
		FileInputStream excelfile = new FileInputStream(TestConstant.path);
		ExcelWorkBook = new XSSFWorkbook(excelfile);
		ExcelWorkSheet = ExcelWorkBook.getSheet(TestConstant.sheetname);
		ExcelWorkSheet.getRow(TestConstant.RowNum).getCell(TestConstant.ColNum).getStringCellValue();
		
		}
		catch(Exception e){
			
			e.printStackTrace();
		}
		
	}
		
	// This method is to read the test data from the Excel cell, in this we are
	// passing parameters as Row num and Col num

}
