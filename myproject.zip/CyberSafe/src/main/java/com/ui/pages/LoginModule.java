package com.ui.pages;

import com.constant.Generic;

/**
 * @author A1SKIVA4
 *
 */

import com.constant.TestConstant;
import com.base.BasePage;
import com.common.Log4j;
import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class LoginModule extends BasePage {

	BasePage page = new BasePage();
	Generic generic = new Generic();

	private static Logger Log = Logger.getLogger(Log4j.class.getName());

	WebDriverWait wait = new WebDriverWait(TestConstant.driver, TestConstant.pageload);

	static String Uname = null;
	static String Pswrd = null;

	static String ForgetUsername = "ECO00001-200001";
	static String ForgetEmail = "megha.sudan@yopmail.com";
	
	public static final String home = "Login.home";
	public static final String entityRegistration = "Login.entityRegistration";
	public static final String userRegistration = "Login.userRegistration";
	

	public boolean validateLogo() {

		try {
			TestConstant.cyber_logo = wait.until(ExpectedConditions.visibilityOfElementLocated(
					By.xpath(utility.ConfigurationFile.getProperty(TestConstant.cyber_logo_ElementField))));
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (TestConstant.cyber_logo.isDisplayed()) {
			Log4j.info("Logo is enabled and Displayed");
		}
		return TestConstant.cyber_logo.isDisplayed();
	}

	public void loginUser() throws Exception {

		try {
			// Enter the path t o your excel here
			FileInputStream fStream = new FileInputStream(
					new File("D:\\Airtel\\Requirement\\Test Data\\Type of All Data.xlsx"));

			/* Create workbook instance referencing the file created above */
			XSSFWorkbook workbook = new XSSFWorkbook(fStream);

			/* Get your first or desired sheet from the workbook */
			XSSFSheet sheet = workbook.getSheetAt(1); // getting first sheet

			/* Get data from the row and column */
			XSSFRow row = sheet.getRow(12);
			XSSFCell cell1 = row.getCell(0);
			XSSFCell cell2 = row.getCell(1);

			Uname = cell1.toString();
			Pswrd = cell2.toString();
			fStream.close();

		} catch (Exception e) {

			e.printStackTrace();
		}

		/* Enter Username */
		TestConstant.username = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath(utility.ConfigurationFile.getProperty(TestConstant.usernameElementField))));
		TestConstant.username.sendKeys(Uname);

		/* Enter Password */
		TestConstant.password = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath(utility.ConfigurationFile.getProperty(TestConstant.passwordElementField))));
		TestConstant.password.sendKeys(Pswrd);
		
		TestConstant.driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		/* Login button */
		TestConstant.login_btn = wait.until(ExpectedConditions.elementToBeClickable(
				By.xpath(utility.ConfigurationFile.getProperty(TestConstant.ButtonElementField))));
		TestConstant.login_btn.click();

		Thread.sleep(4000);

		/* OTP Pop up */

		TestConstant.driver.findElement(By.xpath("//div[@id='otp_modal']//div[@class='modal-body']"));
		String OTP_Message = TestConstant.driver.findElement(By.xpath("//p[@class='otp_msg']")).getText();
		Log4j.info("" + OTP_Message);
		TestConstant.OTP_Digit = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath(utility.ConfigurationFile.getProperty(TestConstant.OTP_DigitElementField))));
		// TestConstant.OTP_Digit.sendKeys("123456");
		Thread.sleep(12000);

		String OTP_Count = TestConstant.driver.findElement(By.xpath("//div[@class='countdown']")).getText();
		Log4j.info("Count down of OTP : " + OTP_Count);
		TestConstant.driver.findElement(By.xpath("//input[@id='bigbutton']")).click();
		Log4j.info("User clicked on OTP popup submit button");

	}

	public void logOut() throws Exception {

		loginUser();
		Log4j.info("Verifying Log Out");
		WebDriverWait wait = new WebDriverWait(TestConstant.driver, TestConstant.pageload);
		TestConstant.log_out_username = TestConstant.driver.findElement(
				By.xpath(utility.ConfigurationFile.getProperty(TestConstant.log_out_usernameElementField)));
		Log4j.info("User Click on LogOut icon");

		// *[@id="Logout_link"]
		Actions act = new Actions(TestConstant.driver);
		act.moveToElement(TestConstant.log_out_username).build().perform();
		TestConstant.log_out_username.click();
		Thread.sleep(1000);

		TestConstant.log_out = TestConstant.driver
				.findElement(By.xpath(utility.ConfigurationFile.getProperty(TestConstant.logOutUserIconElementField)));

		act.moveToElement(TestConstant.log_out).build().perform();
		// act.click(TestConstant.Log4j_out);

		if (TestConstant.log_out.isDisplayed()) {

			TestConstant.log_out.click();
			Log4j.info("Clicked on Log Out button.");

		} else {
			Log4j.info("LogOut element is not accessible.");
		}
	}

	/* Session Expire, and Timeout error message */
	public void sessionTimeOut() {

		TestConstant.driver.manage().timeouts().implicitlyWait(11, TimeUnit.MINUTES);
		String session_expire_msg = TestConstant.driver
				.findElement(
						By.xpath("//p[contains(text(),'You have been logged out because your session has expired.')]"))
				.getText();
		if (session_expire_msg == "You have been logged out because your session has expired.") {
			Log4j.info("Your session has expired, Please reload the page and login.");
		}
		Assert.assertTrue(false);
	}

	public void autoLogout() throws Exception {

		loginUser();
		Log4j.info("Verifying auto-Logout");
		Log4j.info("Auto Log4jout will be done in 10 minutes");
		Thread.sleep(100000);
		TestConstant.driver.getTitle();
		if (TestConstant.driver.getTitle() == TestConstant.cybersafe_URL) {
			Log4j.info("CyberSafe Login Page");

		} else {

			Log4j.info(TestConstant.driver.getTitle());
		}
	}

	public void forgetPassword() throws Exception {

		Log4j.info("Forget password link for the user to reset password");

		// TestConstant.driver.findElement(By.xpath("//a[contains(text(),'Forgot
		// Password?')]")).click();
		TestConstant.forgetPassword = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath(utility.ConfigurationFile.getProperty(TestConstant.forgetPasswordElementField))));
		TestConstant.forgetPassword.click();

		TestConstant.forget_username = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath(utility.ConfigurationFile.getProperty(TestConstant.forgetUsernameElementField))));
		TestConstant.forget_username.sendKeys(ForgetUsername);

		TestConstant.forget_email = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath(utility.ConfigurationFile.getProperty(TestConstant.forgetEmailIDElementField))));
		TestConstant.forget_email.sendKeys(ForgetEmail);

		TestConstant.forget_submit_btn = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath(utility.ConfigurationFile.getProperty(TestConstant.forgetSubmitElementField))));
		TestConstant.forget_submit_btn.click();

		String forgetSuccessMsg = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Password reset URL sent on your Email')]")))
				.getText();

		generic.takeScreenshot(TestConstant.driver, "ForgetPasswordSuccess");

		if (forgetSuccessMsg == "Password reset URL sent on your Email") {
			TestConstant.driver.navigate().back();
			Log4j.info("Navigate to login page to re-login");
			if (page.titleOfCurrentPage() == "Cyber Safe") {

				TestConstant.driver.navigate().refresh();
			}

			else if (forgetSuccessMsg != "Password reset URL sent on your Email") {

				String forgetErrorMsg = wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Invalid Username or Email ID')]")))
						.getText();
				if (forgetErrorMsg == "Invalid Username or Email ID") {

					TestConstant.driver.navigate().refresh();
					Log4j.info("Navigate to login page after refresh the page");

				}
			}
		}

	}

	public void LoginInfo() throws Exception {

		loginUser();
		Log4j.info("Verifing who is Logged in and last login date & time");
		String Last_Login = TestConstant.driver.findElement(By.xpath("//div[@id='last-login']")).getText();
		Log4j.info(Last_Login);

	}

}
