package com.constant;

/**
 * @author A1SKIVA4
 *
 */

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;

import com.constant.TestConstant;

public class Generic {

	Generic generic;
	// This is Constructor
	public Generic() { // Constructor

	}

	public void waitWebDriver() {

		WebDriverWait wait = new WebDriverWait(TestConstant.driver, 2000);

	}

	/* This is method is to take a screenshot of the page */
	public void takeScreenshot(WebDriver driver, String screenshottaken) throws Exception {

		try {

			TakesScreenshot screen = (TakesScreenshot) TestConstant.driver;
			File srcfile = screen.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(srcfile, new File("./screenshot/" + screenshottaken + ".jpeg"));
			System.out.println("Screenshot" + "---" + screenshottaken + ".jpeg");

		} catch (WebDriverException ex) {
			ex.printStackTrace();
			System.out.println("Exception occure while taking a screenshot" + ex.getMessage());
		}

	}

	@AfterMethod
	public void failTestCase(ITestResult result) throws Exception {

		if (ITestResult.FAILURE == result.getStatus()) {

			generic.takeScreenshot(TestConstant.driver, result.getName());
		}

	}

	public void genericPageNavigation(String type) throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(TestConstant.driver, TestConstant.pageload);

			if (type.equals("HEamder")) {
				TestConstant.entityHeaderClick = wait.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath(utility.ConfigurationFile.getProperty(TestConstant.entityHeaderClickElementFiled))));
				TestConstant.entityHeaderClick.click();
			}

		} finally {

		}

	}

}
