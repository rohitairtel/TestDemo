package com.base;
/**
 * @author A1SKIVA4
 *
 */

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.common.Log4j;
import com.constant.TestConstant;

import junit.framework.Assert;

public class BasePage {

	// public WebDriver driver;
	public WebDriverWait wait;

	public static WebElement FCORD_MHA_GOI;
	public static WebElement Partner_APB;

	public static WebElement Home;
	public static WebElement Entity_Registration;
	public static WebElement User_Registration;



	/* Constructor */
	public BasePage() {

	}

	public void visibilityOfElement(By elementBy) {

		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(elementBy));
	}

	/* Click on element */
	public void click(By elementBy) {
		visibilityOfElement(elementBy);
		TestConstant.driver.findElement(elementBy).click();

	}

	/* Read element */
	public String readText(By elementBy) {
		visibilityOfElement(elementBy);
		return TestConstant.driver.findElement(elementBy).getText();

	}

	public String titleOfCurrentPage() {
		return TestConstant.driver.getTitle();
	}

	public boolean footers() {

		FCORD_MHA_GOI = TestConstant.driver.findElement(By.xpath("//a[@id='initiative_of']"));
		Partner_APB = TestConstant.driver.findElement(By.xpath("//a[@id='technology_partner']"));

		if (FCORD_MHA_GOI.isDisplayed()) {
			String MHA_FCord = TestConstant.driver.findElement(By.xpath("//a[@id='initiative_of']")).getText().trim();
			Assert.assertTrue(true);
			Log4j.info(" Footer of MHA FCORD is : " + MHA_FCord);
		}
		if (Partner_APB.isDisplayed()) {
			String Technology_partner = TestConstant.driver.findElement(By.xpath("//a[@id='technology_partner']"))
					.getText().trim();
			Assert.assertTrue(true);
			Log4j.info(" Footer of MHA FCORD is : " + Technology_partner);
		}
		return FCORD_MHA_GOI.isDisplayed() && Partner_APB.isDisplayed();

	}

	public boolean headers() {
		
		 Home = TestConstant.driver.findElement(By.xpath("// strong[contains(text(),'Home')]"));
		 Entity_Registration = TestConstant.driver.findElement(By.xpath("//strong[contains(text(),'Entity Registration')]"));
		 User_Registration = TestConstant.driver.findElement(By.xpath("//strong[contains(text(),'User Registration')]"));
		 
		return Home.isDisplayed() && Entity_Registration.isDisplayed() && User_Registration.isDisplayed();
	}

}
