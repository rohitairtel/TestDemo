package com.base;

/**
 * @author A1SKIVA4
 *
 */
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import org.testng.annotations.*;
import java.util.Properties;

import com.constant.TestConstant;
import com.common.ExcelUtils;
import com.common.Log4j;

public class BaseTest {

	public static Properties prop;

	public BaseTest() {

	}

	public WebDriver getInstance() throws Exception {

		if (TestConstant.driver == null || ((RemoteWebDriver) TestConstant.driver).getSessionId() == null)
			initializeDriver();
		return TestConstant.driver;

	}

	public void initializeDriver() {

		DOMConfigurator.configure("D:\\Eclipse\\CyberSafe\\log4j.xml");

		System.setProperty(TestConstant.driver_chrome, TestConstant.setProperty_chrome);
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		// this line of code is to resolve protected mode issue
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability("requireWindowFocus", true);
		capabilities.setCapability("enablePersistentHover", false);
		TestConstant.driver = new ChromeDriver();
		TestConstant.sTestCaseName = this.toString();
		TestConstant.sTestCaseName = ExcelUtils.getTestCaseName(this.toString());
		Log4j.startTestCase(TestConstant.sTestCaseName);
		TestConstant.driver.manage().window().maximize();
		TestConstant.driver.manage().deleteAllCookies();
		TestConstant.driver.get(TestConstant.cybersafe_URL);

	}

	
	//Extent Reports and also to create the object of FileInputStream which is responsible for pointing towards the file from which the data should be read.
	
	
	/*
	 * public void startTestCase() {
	 * 
	 * DOMConfigurator.configure("log4j.xml");
	 * 
	 * Log4j.info(
	 * "****************************************************************************************"
	 * ); Log4j.info("$$$$$$$$$$$$$$$$$$$$$             " + "" +
	 * "           $$$$$$$$$$$$$$$$$$$$$$$$$"); Log4j.info(
	 * "****************************************************************************************"
	 * );
	 * 
	 * }
	 * 
	 * 
	 * public void endTestCase() {
	 * 
	 * DOMConfigurator.configure("log4j.xml");
	 * 
	 * Log4j.info(
	 * "****************************************************************************************"
	 * ); Log4j.info("XXXXXXXXXXXXXXXXXXXXXXX             " + "-E---N---D-" +
	 * "             XXXXXXXXXXXXXXXXXXXXXX");
	 * Log4j.info("*********************************" + "" +
	 * " **********************************");
	 * 
	 * }
	 */

	public void terminate() {

		TestConstant.driver.manage().deleteAllCookies();
		TestConstant.driver.close();
		TestConstant.driver.quit();

	}
}
