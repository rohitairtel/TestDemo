package testcase;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.base.BasePage;
import com.base.BaseTest;
import com.common.Log4j;
import com.constant.TestConstant;
import com.ui.pages.LoginModule;

import freemarker.template.Configuration;
import utility.ConfigurationFile;

public class LoginTestCase extends BaseTest {

	public BaseTest test;
	public BasePage page;
	public LoginModule logged;

	@BeforeTest
	public void startTestCase() {
		/*
		 * DOMConfigurator.configure("D:\\Eclipse\\CyberSafe\\log4j.xml"); Log4j.info(
		 * "****************************************************************************************"
		 * ); Log4j.info("XXXXXXXXXXXXXXXXXXXXXXX           " + "-S-T-A-R-T-" +
		 * "           XXXXXXXXXXXXXXXXXXXXXX");
		 */
	}

	@AfterTest
	public void endTestCase() {
		DOMConfigurator.configure("D:\\Eclipse\\CyberSafe\\log4j.xml");
		Log4j.info("XXXXXXXXXXXXXXXXXXXXXXX           " + "-E---N---D-" + "           XXXXXXXXXXXXXXXXXXXXXX");
	}

	@Test(priority = 0, description = "TEST CASE - 1 : Verify that Address(URL) of the application", enabled = true)
	public void loginTitle() throws Exception {
		Log4j.info("TEST CASE - 1 : Verify that Address(URL) of the application");
		
		initializeDriver();
		page = new BasePage();
		Log4j.info("Title of current page is : " + page.titleOfCurrentPage());
		Log4j.info(TestConstant.driver.getCurrentUrl());
		terminate();
	}

	@Test(priority = 1, description = "TEST CASE - 2 : Verify that logo is enabled and displayed", enabled = true)
	public void logo() throws Exception {
		Log4j.info("TEST CASE - 2 : Verify that logo is enabled and displayed");
		
		initializeDriver();
		logged = new LoginModule();
		logged.validateLogo();
		terminate();

	}

	@Test(priority = 2, description = "TEST CASE - 3 : Verify that user able to login into application", enabled = false)
	public void logintoCyberSafe() throws Exception {
		Log4j.info("TEST CASE - 3 : Verify that user able to login into application");
		
		initializeDriver();
		logged = new LoginModule();
		logged.loginUser();
		terminate();

	}

	@Test(priority = 3, description = "TEST CASE - 4 : Verify that user able to do log Out from application", enabled = false)
	public void logout() throws Exception {
		Log4j.info("TEST CASE - 4 : Verify that user able to do log Out from application");
		
		initializeDriver();
		logged = new LoginModule();
		logged.logOut();
		terminate();
	}

	@Test(priority = 4, description = "TEST CASE - 5 : Verify that footers at login page", enabled = true)
	public void footerAtLogin() throws Exception {
		Log4j.info("TEST CASE - 5 : Verify that footers at login page");
		
		initializeDriver();
		page = new BasePage();
		page.footers();
		terminate();
	}

	@Test(priority = 5, description = "TEST CASE - 6 : Verify that headers at login page", enabled = false)
	public void headerAtLogin() throws Exception {
		Log4j.info("TEST CASE - 6 : Verify that headers at login page");
		
		initializeDriver();
		page = new BasePage();
		page.headers();

	}

	@Test(priority = 6, description = "TEST CASE - 7 : Verify that all lable present into login page", enabled = false)
	public void labelText() throws Exception {
		Log4j.info("TEST CASE - 7 : Verify that all lable present into login page");
		
		initializeDriver();
		terminate();
	}

	@Test(priority = 10, description = "TEST CASE - 8 : Verify that error message on session expired", enabled = false)
	public void expireSession() throws Exception {
		Log4j.info("TEST CASE - 8 : Verify that error message on session expired");
		
		initializeDriver();
		logged.sessionTimeOut();
		terminate();
	}

	@Test(priority = 7, description = "TEST CASE - 9 : Verify that auto logout if user is inactive into application", enabled = false)
	public void autoLogOut() throws Exception {
		Log4j.info("TEST CASE - 9 : Verify that auto logout if user is inactive into application");
		
		initializeDriver();
		logged.autoLogout();
		terminate();
	}

	@Test(priority = 8, description = " Verify that User able to change forget password. ", enabled = true)
	public void forget_reset_Password() throws Exception {
		Log4j.info("TEST CASE - 10 : Verify that User able to change forget password.");
		
		initializeDriver();
		logged = new LoginModule();
		try {
			logged.forgetPassword();
		} catch (Exception e) {

			e.printStackTrace();
		}

	}
	
	@Test(priority = 9, description = "Verify that Last Logged-in info displayed", enabled = true)
	public void userLoggedInInfo() throws Exception {
		Log4j.info("Verify that Last Logged-in info displayed");
		
		initializeDriver();
		logged = new LoginModule();
		logged.LoginInfo();
		terminate();
		
		
	}
	
	
	@Test(description = "Verify that user able to navigate Home & Entity/User Registration and then Back to Login")
	public void verifyBackOperation() {
		
		initializeDriver();
		
		
		
		
		
	}

}
